package miniproject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverSetup{
	    public static WebDriver driver; 
	    public void initialize() {
	        String browser = ConfigReader.get("browser");
	        if (browser.equalsIgnoreCase("chrome")) {
	            driver = new ChromeDriver();
	        } else if (browser.equalsIgnoreCase("firefox")) {
	            driver = new FirefoxDriver();
	        }
	            else if(browser.equalsIgnoreCase("Edge")){
	            	driver=new EdgeDriver();
	          
	        } 
	    }
	    
	    public WebDriver GetDriver() {
	    	initialize();
	        driver.manage().window().maximize();
	        // Open the URL
	        driver.get(ConfigReader.get("baseUrl"));
	        return driver;
	    }
}

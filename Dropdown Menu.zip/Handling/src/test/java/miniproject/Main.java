package miniproject;

import java.util.List;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Main {

	//private static final CharSequence Kamal = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DriverSetup d = new DriverSetup();
		WebDriver driver = d.GetDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		//Click on "Create a new account link"
		Actions act=new Actions(driver);
		act.doubleClick(driver.findElement(By.xpath("//div[@class='signup-link']/p/a"))).perform();
		
	   //Enter the name as “Kamal” and Rediff mail as “kamal1234” and click on “Check Availability” button.
	   driver.findElement(By.xpath("//input[@placeholder='Enter your full name']")).sendKeys("Kamal");
	   driver.findElement(By.xpath("//input[@placeholder='Enter Rediffmail ID']")).sendKeys("kamal1234");
	  
	   //Click on Check Availability
	   act.doubleClick(driver.findElement(By.xpath("//input[@value='Check availability']"))).perform();
	   
	   //Select one of the auto suggested mail options
	   act.doubleClick(driver.findElement(By.xpath("//tr[1]//td[1]//input[@id='radio_login']"))).perform();
	   
	   //Enter the password
	   driver.findElement(By.xpath("//input[@placeholder='Enter password']")).sendKeys("Kamal@1234");

	   //Select the Date of Birth “20-Jun-2000”
	   new Select(driver.findElement(By.className("day"))).selectByValue("20");
       new Select(driver.findElement(By.cssSelector("select.middle.month"))).selectByValue("06");
       new Select(driver.findElement(By.className("year"))).selectByValue("2000");

       //Click on Country dropdown list box
       act.doubleClick(driver.findElement(By.id("country"))).perform();
       
       //Fetch all the available country names and display on console
	   Select countrySelect = new Select(driver.findElement(By.id("country")));
       java.util.List<WebElement> allOptions = countrySelect.getOptions();
       java.util.List<String> countryNames = new java.util.ArrayList<>();
       for (WebElement option : allOptions) {
           String text = option.getText().trim();
           if (!text.isEmpty()) {
               countryNames.add(text);
           }
       }
       
       //Print the total count of countries.
       System.out.println("Total count of countries fetched: " + countryNames);
       System.out.println("Total count of countries fetched: " + countryNames.size());
       
       //Select the Checkbox “Click if you don't have an alternate ID”
       act.doubleClick(driver.findElement(By.className("nomargin"))).perform();
       
       
       //Select Country with Visible Text=”India” 
       countrySelect.selectByVisibleText("India");
       
       List<WebElement> list=countrySelect.getAllSelectedOptions();
     
 
      //Print the name of country selected on console
        System.out.println(list.get(0).getText());

       //Validate the selected country against the expected i.e, India
       String expectedCountry = "India";
       String selectedCountryName=list.get(0).getText();
       
       if (selectedCountryName.equals(expectedCountry)) {
           System.out.println("Validation successful: Selected country '" + selectedCountryName + "' matches expected '" + expectedCountry + "'.");
       } else {
           System.out.println("Validation failed: Selected country '" + selectedCountryName + "' does NOT match expected '" + expectedCountry + "'.");
       }
       
       //Close the browser
       driver.quit();
	}
}

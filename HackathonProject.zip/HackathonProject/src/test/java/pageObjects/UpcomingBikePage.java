package pageObjects;

public class UpcomingBikePage extends BasePage{
  
	public UpcomingBikePage(WebDriver driver) {
		super(driver);
	}
	
}
